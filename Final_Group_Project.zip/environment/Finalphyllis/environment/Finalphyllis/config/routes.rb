Rails.application.routes.draw do
  devise_for :users
  resources :courses do
    member do
      get :addcourse
      get :courselist
    
    
    end
  end
  resources :teachers
  root 'courses#index'
end
